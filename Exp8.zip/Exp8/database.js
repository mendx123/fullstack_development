const{MongoClient}=require('mongodb');
const url='mongodb://localhost:27017';
const client=new MongoClient(url);
let collection;
async function connectDB(dbname,table){
      let result =await client.connect();
      let db=result.db(dbname);
      collection=db.collection(table);
      console.log("Database Connected....");
      return collection;
}
exports.getData=async function(name,password){
      collection =await connectDB("csepb1","employee");
      let respose=await collection.find({name:name,password:password}).toArray();
      console.log("from getData method:"+JSON.stringify(respose));
      collection.close;
      return JSON.stringify(respose);
}
exports.insertData=async function (emp) {
      collection=await connectDB("csepb1","employee");
      let respose=await collection.insertOne({name:emp.name,work:emp.work,password:emp.password});
      console.log("record inserted successfully");
      collection.close;
      return JSON.stringify(respose);
      
}
